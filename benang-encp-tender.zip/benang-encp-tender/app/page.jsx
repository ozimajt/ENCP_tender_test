import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, FileText, ShieldCheck } from "lucide-react";
import Image from "next/image";

export default function ENCPTenderWebsite() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <header className="bg-gradient-to-r from-[#003057] to-[#005B8F] text-white p-6 shadow-md flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Image src="/benang-logo.png" alt="Benang Logo" width={140} height={60} />
          <Image src="/western-power-logo.png" alt="Western Power Logo" width={160} height={60} />
        </div>
        <h1 className="text-2xl font-bold">ENCP Minor Works Panel Tender – WS5197540698</h1>
      </header>

      <main className="p-6">
        <Tabs defaultValue="capability" className="w-full">
          <TabsList className="flex flex-wrap gap-2">
            <TabsTrigger value="capability">Capability</TabsTrigger>
            <TabsTrigger value="mobilisation">Mobilisation</TabsTrigger>
            <TabsTrigger value="management">Project Management</TabsTrigger>
            <TabsTrigger value="reporting">Reporting</TabsTrigger>
            <TabsTrigger value="risk">Risk</TabsTrigger>
            <TabsTrigger value="subcontractors">Subcontractors</TabsTrigger>
            <TabsTrigger value="quality">Quality</TabsTrigger>
            <TabsTrigger value="value">Value Add</TabsTrigger>
            <TabsTrigger value="safety">Safety</TabsTrigger>
          </TabsList>

          <TabsContent value="capability">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Capability and Experience</h2>
                <p>Benang Energy confirms its updated capabilities across civil, electrical, underground, tilt-up and fibre works – with ISO certifications, proven track record, and a highly experienced team delivering complex utility projects across WA.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mobilisation">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Mobilisation Strategy</h2>
                <p>Ready-to-deploy teams, modern plant fleet, established supplier and subcontractor networks, and structured mobilisation planning ensure Benang can begin works from Day 1.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="management">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Project Management</h2>
                <p>Benang employs ISO-aligned methodologies, project controls, WBS scheduling, and real-time reporting, ensuring reliable and quality-driven project delivery with tailored PMP frameworks.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reporting">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Reporting and Monitoring</h2>
                <p>Progress and cost metrics are tracked through daily logs and integrated dashboards (Power BI), with weekly and monthly client reporting aligned to Western Power’s oversight needs.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="risk">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Risk Management</h2>
                <p>Benang's draft ENCP-specific Risk Management Plan identifies major risks and control strategies through the CRAW process, integrated into planning and daily execution.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subcontractors">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Subcontractor Strategy</h2>
                <p>Benang ensures fair engagement, compliance, payment practices and local Aboriginal and regional participation, meeting WAIPS and social procurement targets.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quality">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Quality Assurance</h2>
                <p>Benang’s ISO 9001 system is backed by ITPs, NCR tracking, regular audits and lessons learned processes, tailored to Western Power’s QA requirements.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="value">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Value Add</h2>
                <p>Indigenous ownership, local employment, social inclusion, sustainability measures and industry upskilling initiatives ensure lasting value aligned with Western Power’s strategic goals.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="safety">
            <Card className="mt-4">
              <CardContent className="prose max-w-none p-4">
                <h2>Safety, Health & Environment</h2>
                <p>Zero LTIs, zero prosecutions, ISO 45001 and 14001 certified systems, and proactive continuous improvement underpin Benang’s Zero Harm commitment.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
